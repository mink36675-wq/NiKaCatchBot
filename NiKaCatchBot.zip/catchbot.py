import logging
import random
import sqlite3
import os

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# ====================================
# JustFriend Catch Bot
# ====================================

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
MESSAGES_PER_CARD = 100
OWNER_ID = 2039670756

RARITIES = {
    "Common": 40,
    "Rare": 25,
    "Epic": 15,
    "Legendary": 10,
    "Mythic": 5,
    "Divine": 2.5,
    "CrossVerse": 1.5,
    "Cataphract": 0.7,
    "Supreme": 0.3,
}

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.WARNING,
)

# ====================================
# Database
# ====================================

db = sqlite3.connect(
    "catchbot.db",
    check_same_thread=False,
)

db.execute("PRAGMA journal_mode=WAL")

db.execute("""
CREATE TABLE IF NOT EXISTS characters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE COLLATE NOCASE,
    rarity TEXT NOT NULL,
    image_id TEXT
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS collections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT,
    character_id INTEGER NOT NULL,
    caught_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, character_id)
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS active_catches (
    chat_id INTEGER PRIMARY KEY,
    character_id INTEGER NOT NULL
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS chat_counts (
    chat_id INTEGER PRIMARY KEY,
    message_count INTEGER DEFAULT 0
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS coin_accounts (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    coins INTEGER NOT NULL DEFAULT 1000
)
""")
db.commit()


def get_character(character_id):
    return db.execute(
        """
        SELECT id, name, rarity, image_id
        FROM characters
        WHERE id = ?
        """,
        (character_id,),
    ).fetchone()


# ====================================
# Start
# ====================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    register_member(update.effective_user)
    text = (
        "🎮 JustFriend Catch Bot\n\n"
        "Group ထဲမှာ စကားပြောရင်း Anime နဲ့ Novel "
        "Character တွေကို Catch လုပ်ကြမယ်!\n\n"
        "📌 Commands\n"
        "/catch — Character ပေါ်စေမယ်\n"
        "/collection — ကိုယ်ဖမ်းထားတာကြည့်မယ်\n"
        "/top — Leaderboard ကြည့်မယ်\n"
        "/rarities — Rarity အဆင့်တွေကြည့်မယ်\n"
        "/count — လက်ရှိစာရေတွက်မှုကြည့်မယ်\n"
        "/addcharacter — Character ထည့်မယ်\n"
        "/addphoto — ပုံနဲ့ Character ထည့်မယ်"
    )

    await update.effective_message.reply_text(text)



# === COIN SYSTEM START ===

CARD_VALUES = {
    "Common": (500, 250),
    "Rare": (1000, 500),
    "Epic": (3000, 1500),
    "Legendary": (5000, 2500),
    "Mythic": (10000, 5000),
    "Divine": (25000, 12500),
    "CrossVerse": (50000, 25000),
    "Cataphract": (100000, 50000),
    "Supreme": (500000, 250000),
}


def register_member(user):
    if user is None:
        return
    db.execute(
        """INSERT OR IGNORE INTO coin_accounts
           (user_id, username, coins) VALUES (?, ?, 1000)""",
        (user.id, user.username),
    )
    db.execute(
        "UPDATE coin_accounts SET username = ? WHERE user_id = ?",
        (user.username, user.id),
    )
    db.commit()


async def mycoin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    register_member(user)

    if user.id == OWNER_ID:
        await update.effective_message.reply_text(
            f"👑 Owner ID: {user.id}\n♾️ Coin: အကန့်အသတ်မရှိ"
        )
        return

    row = db.execute(
        "SELECT coins FROM coin_accounts WHERE user_id = ?",
        (user.id,),
    ).fetchone()

    await update.effective_message.reply_text(
        f"🪙 Your ID: {user.id}\n💰 Your Coin: {row[0]:,}"
    )


async def prices(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = "🎴 Card Prices\n\n"
    for rarity, (buy, sell) in CARD_VALUES.items():
        text += (
            f"• {rarity}\n"
            f"  ဝယ်ဈေး: {buy:,} Coin\n"
            f"  ရောင်းဈေး: {sell:,} Coin\n\n"
        )
    await update.effective_message.reply_text(text)


def is_owner(update):
    return (
        update.effective_user is not None
        and update.effective_user.id == OWNER_ID
    )


async def givecoin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        await update.effective_message.reply_text("⛔ Owner သာ အသုံးပြုနိုင်ပါတယ်။")
        return
    try:
        target, amount = int(context.args[0]), int(context.args[1])
        if amount <= 0:
            raise ValueError
    except (ValueError, IndexError):
        await update.effective_message.reply_text(
            "အသုံးပြုပုံ: /givecoin USER_ID AMOUNT"
        )
        return

    db.execute(
        "INSERT OR IGNORE INTO coin_accounts (user_id, username, coins) VALUES (?, NULL, 0)",
        (target,),
    )
    db.execute(
        "UPDATE coin_accounts SET coins = coins + ? WHERE user_id = ?",
        (amount, target),
    )
    db.commit()
    await update.effective_message.reply_text(
        f"✅ ID {target} ကို {amount:,} Coin ပေးပြီးပါပြီ။"
    )


async def takecoin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        await update.effective_message.reply_text("⛔ Owner သာ အသုံးပြုနိုင်ပါတယ်။")
        return
    try:
        target, amount = int(context.args[0]), int(context.args[1])
        if amount <= 0:
            raise ValueError
    except (ValueError, IndexError):
        await update.effective_message.reply_text(
            "အသုံးပြုပုံ: /takecoin USER_ID AMOUNT"
        )
        return

    row = db.execute(
        "SELECT coins FROM coin_accounts WHERE user_id = ?",
        (target,),
    ).fetchone()
    if row is None or row[0] < amount:
        await update.effective_message.reply_text(
            "❌ Member မရှိပါ၊ သို့မဟုတ် Coin မလုံလောက်ပါ။"
        )
        return

    db.execute(
        "UPDATE coin_accounts SET coins = coins - ? WHERE user_id = ?",
        (amount, target),
    )
    db.commit()
    await update.effective_message.reply_text(
        f"✅ ID {target} ဆီမှ {amount:,} Coin နုတ်ပြီးပါပြီ။"
    )


async def setcoin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        await update.effective_message.reply_text("⛔ Owner သာ အသုံးပြုနိုင်ပါတယ်။")
        return
    try:
        target, amount = int(context.args[0]), int(context.args[1])
        if amount < 0:
            raise ValueError
    except (ValueError, IndexError):
        await update.effective_message.reply_text(
            "အသုံးပြုပုံ: /setcoin USER_ID AMOUNT"
        )
        return

    db.execute(
        """INSERT INTO coin_accounts (user_id, username, coins)
           VALUES (?, NULL, ?)
           ON CONFLICT(user_id) DO UPDATE SET coins = excluded.coins""",
        (target, amount),
    )
    db.commit()
    await update.effective_message.reply_text(
        f"✅ ID {target} ရဲ့ Coin ကို {amount:,} အဖြစ် သတ်မှတ်ပြီးပါပြီ။"
    )

# === COIN SYSTEM END ===


# ====================================
# Rarity
# ====================================

async def rarities(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = "💎 JustFriend Catch Bot Rarity\n\n"

    for name, chance in RARITIES.items():
        text += f"• {name}: {chance}%\n"

    await update.effective_message.reply_text(text)


# ====================================
# Spawn Character
# ====================================

async def spawn_character(chat_id, message):
    existing = db.execute(
        "SELECT character_id FROM active_catches WHERE chat_id = ?",
        (chat_id,),
    ).fetchone()

    if existing:
        await message.reply_text(
            "🎯 Character တစ်ကောင် ပေါ်နေပြီ။ "
            "အရင်ဆုံး နာမည်မှန်အောင် ရိုက်ပြီး Catch လုပ်ပါ။"
        )
        return

    characters = db.execute(
        """
        SELECT id, name, rarity, image_id
        FROM characters
        """
    ).fetchall()

    if not characters:
        await message.reply_text(
            "📭 Character မရှိသေးပါ။\n"
            "Admin က Character ထည့်ပေးပါ။"
        )
        return

    # Rarity ကို အရင်ရွေးပြီး သက်ဆိုင်ရာ Character ရွေးမယ်
    rarity_names = list(RARITIES.keys())
    weights = list(RARITIES.values())

    selected_rarity = random.choices(
        rarity_names,
        weights=weights,
        k=1,
    )[0]

    matching = [
        character
        for character in characters
        if character[2] == selected_rarity
    ]

    # ရွေးထားတဲ့ Rarity မရှိသေးရင်
    # ရှိနေတဲ့ Rarity ထဲက ရွေးမယ်
    if not matching:
        available_rarities = list({
            character[2] for character in characters
        })

        available_weights = [
            RARITIES[r]
            for r in available_rarities
        ]

        selected_rarity = random.choices(
            available_rarities,
            weights=available_weights,
            k=1,
        )[0]

        matching = [
            character
            for character in characters
            if character[2] == selected_rarity
        ]

    character = random.choice(matching)

    db.execute(
        """
        INSERT OR REPLACE INTO active_catches
        (chat_id, character_id)
        VALUES (?, ?)
        """,
        (chat_id, character[0]),
    )
    db.commit()

    caption = (
        "✨ A WILD CHARACTER HAS APPEARED!\n\n"
        f"💎 Rarity: {character[2]}\n"
        "🎯 Character နာမည်ကို အရင်မှန်အောင် ရိုက်ပါ။\n"
        "🏆 အရင်ဆုံး မှန်တဲ့သူက Catch လုပ်နိုင်မယ်!"
    )

    if character[3]:
        await message.reply_photo(
            photo=character[3],
            caption=caption,
        )
    else:
        await message.reply_text(caption)


async def catch_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    await spawn_character(
        update.effective_chat.id,
        update.effective_message,
    )


# ====================================
# Count group messages
# ====================================

async def count_messages(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user

    if not message or not chat or not user:
        return

    # Group နဲ့ Supergroup မှာပဲ ရေတွက်မယ်
    if chat.type not in ("group", "supergroup"):
        return

    # Bot တွေရဲ့စာ မရေတွက်ပါ
    if user.is_bot:
        return

    # Text မပါရင် မရေတွက်ပါ
    if not message.text:
        return

    # Commands မရေတွက်ပါ
    if message.text.startswith("/"):
        return

    # Database ထဲမှာ စာရေတွက်မယ်
    db.execute(
        """
        INSERT INTO chat_counts (chat_id, message_count)
        VALUES (?, 1)
        ON CONFLICT(chat_id)
        DO UPDATE SET message_count = message_count + 1
        """,
        (chat.id,),
    )

    result = db.execute(
        """
        SELECT message_count
        FROM chat_counts
        WHERE chat_id = ?
        """,
        (chat.id,),
    ).fetchone()

    count = result[0] if result else 0

    db.commit()

    # 100 ကြောင်းပြည့်ရင် Card ပေါ်မယ်
    if count >= MESSAGES_PER_CARD:
        db.execute(
            """
            UPDATE chat_counts
            SET message_count = 0
            WHERE chat_id = ?
            """,
            (chat.id,),
        )
        db.commit()

        await spawn_character(chat.id, message)


async def show_count(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    chat_id = update.effective_chat.id

    result = db.execute(
        """
        SELECT message_count
        FROM chat_counts
        WHERE chat_id = ?
        """,
        (chat_id,),
    ).fetchone()

    count = result[0] if result else 0

    await update.effective_message.reply_text(
        f"💬 စာရေတွက်မှု: {count}/{MESSAGES_PER_CARD}\n"
        f"🎴 နောက် Card ပေါ်ဖို့ {MESSAGES_PER_CARD - count} ကြောင်းလိုသေးတယ်။"
    )


# ====================================
# Guess Character
# ====================================

async def handle_guess(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    message = update.effective_message
    user = update.effective_user
    chat = update.effective_chat

    if not message or not message.text or not user or not chat:
        return

    if chat.type not in ("group", "supergroup"):
        return

    if user.is_bot:
        return

    guess = message.text.strip()

    if guess.startswith("/"):
        return

    active = db.execute(
        """
        SELECT character_id
        FROM active_catches
        WHERE chat_id = ?
        """,
        (chat.id,),
    ).fetchone()

    if not active:
        return

    character = get_character(active[0])

    if not character:
        return

    if guess.casefold() != character[1].casefold():
        return

    username = user.username or user.first_name

    # အရင်ဆုံးမှန်တဲ့သူကိုပဲ ခွင့်ပြုမယ်
    db.execute(
        """
        INSERT OR IGNORE INTO collections
        (user_id, username, character_id)
        VALUES (?, ?, ?)
        """,
        (user.id, username, character[0]),
    )

    inserted = db.execute(
        "SELECT changes()"
    ).fetchone()[0]

    db.execute(
        "DELETE FROM active_catches WHERE chat_id = ?",
        (chat.id,),
    )

    db.commit()

    if inserted == 0:
        await message.reply_text(
            "📚 ဒီ Character ကို မင်းဖမ်းထားပြီးသားပါ။"
        )
        return

    await message.reply_text(
        "🎉 CHARACTER CAUGHT!\n\n"
        f"👤 {user.first_name}\n"
        f"🃏 {character[1]}\n"
        f"💎 Rarity: {character[2]}"
    )


# ====================================
# Collection
# ====================================

async def collection(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    user = update.effective_user

    rows = db.execute(
        """
        SELECT characters.name, characters.rarity
        FROM collections
        JOIN characters
        ON collections.character_id = characters.id
        WHERE collections.user_id = ?
        ORDER BY characters.name
        """,
        (user.id,),
    ).fetchall()

    if not rows:
        await update.effective_message.reply_text(
            "📚 မင်းမှာ Character မရှိသေးဘူး။"
        )
        return

    text = f"📚 {user.first_name} ရဲ့ Collection\n\n"

    for name, rarity in rows[:50]:
        text += f"• {name} — {rarity}\n"

    text += f"\nစုစုပေါင်း Character: {len(rows)}"

    await update.effective_message.reply_text(text)


# ====================================
# Leaderboard
# ====================================

async def top(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    rows = db.execute(
        """
        SELECT username, user_id, COUNT(*)
        FROM collections
        GROUP BY user_id
        ORDER BY COUNT(*) DESC
        LIMIT 10
        """
    ).fetchall()

    if not rows:
        await update.effective_message.reply_text(
            "🏆 Leaderboard မရှိသေးပါ။"
        )
        return

    text = "🏆 JUSTFRIEND CATCH TOP 10\n\n"

    for rank, (username, user_id, total) in enumerate(rows, 1):
        name = username or f"User {user_id}"
        text += f"{rank}. {name} — {total} ကောင်\n"

    await update.effective_message.reply_text(text)


# ====================================
# Add Character
# ====================================

async def addcharacter(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    if not context.args:
        await update.effective_message.reply_text(
            "အသုံးပြုပုံ:\n"
            "/addcharacter Sung Jinwoo | Mythic"
        )
        return

    raw = " ".join(context.args)
    parts = [part.strip() for part in raw.split("|")]

    if len(parts) != 2:
        await update.effective_message.reply_text(
            "နာမည်နဲ့ Rarity ကြားမှာ | ထည့်ပါ။"
        )
        return

    name, rarity = parts

    if not name:
        await update.effective_message.reply_text(
            "Character နာမည် ထည့်ပါ။"
        )
        return

    if rarity not in RARITIES:
        await update.effective_message.reply_text(
            "Rarity မမှန်ပါ။ /rarities ကိုကြည့်ပါ။"
        )
        return

    try:
        db.execute(
            """
            INSERT INTO characters (name, rarity)
            VALUES (?, ?)
            """,
            (name, rarity),
        )
        db.commit()

        await update.effective_message.reply_text(
            f"✅ Character ထည့်ပြီးပါပြီ!\n\n"
            f"👤 {name}\n"
            f"💎 {rarity}"
        )

    except sqlite3.IntegrityError:
        await update.effective_message.reply_text(
            "ဒီ Character ရှိပြီးသားပါ။"
        )


# ====================================
# Add Character With Image
# ====================================

async def addphoto(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    message = update.effective_message

    if not message or not message.photo:
        return

    caption = message.caption or ""

    if not caption.startswith("/addphoto"):
        return

    raw = caption.replace("/addphoto", "", 1).strip()
    parts = [part.strip() for part in raw.split("|")]

    if len(parts) != 2:
        await message.reply_text(
            "ဓာတ်ပုံနဲ့ Caption ကို ဒီလိုပို့ပါ:\n"
            "/addphoto Sung Jinwoo | Mythic"
        )
        return

    name, rarity = parts

    if not name:
        await message.reply_text(
            "Character နာမည် ထည့်ပါ။"
        )
        return

    if rarity not in RARITIES:
        await message.reply_text(
            "Rarity မမှန်ပါ။ /rarities ကိုကြည့်ပါ။"
        )
        return

    image_id = message.photo[-1].file_id

    existing = db.execute(
        "SELECT id FROM characters WHERE name = ? COLLATE NOCASE",
        (name,),
    ).fetchone()

    if existing:
        db.execute(
            """
            UPDATE characters
            SET rarity = ?, image_id = ?
            WHERE id = ?
            """,
            (rarity, image_id, existing[0]),
        )

        await message.reply_text(
            f"🖼️ {name} ရဲ့ပုံကို ပြောင်းပြီးပါပြီ။"
        )

    else:
        db.execute(
            """
            INSERT INTO characters (name, rarity, image_id)
            VALUES (?, ?, ?)
            """,
            (name, rarity, image_id),
        )

        await message.reply_text(
            f"✅ Character အသစ်ထည့်ပြီးပါပြီ!\n"
            f"👤 {name}\n"
            f"💎 {rarity}"
        )

    db.commit()


# ====================================
# Error Handler
# ====================================

async def error_handler(
    update: object,
    context: ContextTypes.DEFAULT_TYPE,
):
    logging.error(
        "Bot error: %s",
        context.error,
    )


# ====================================
# Main
# ====================================

def main():
    if BOT_TOKEN == "YOUR_BOT_TOKEN":
        print("❌ BOT_TOKEN ကို အရင်ထည့်ပါ။")
        return

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("mycoin", mycoin))
    app.add_handler(CommandHandler("prices", prices))
    app.add_handler(CommandHandler("shop", prices))
    app.add_handler(CommandHandler("givecoin", givecoin))
    app.add_handler(CommandHandler("takecoin", takecoin))
    app.add_handler(CommandHandler("setcoin", setcoin))
    app.add_handler(CommandHandler("rarities", rarities))
    app.add_handler(CommandHandler("catch", catch_command))
    app.add_handler(CommandHandler("count", show_count))
    app.add_handler(CommandHandler("collection", collection))
    app.add_handler(CommandHandler("top", top))
    app.add_handler(CommandHandler("addcharacter", addcharacter))

    # Photo နဲ့ Character ထည့်မယ်
    app.add_handler(
        MessageHandler(filters.PHOTO, addphoto)
    )

    # Group message တွေကို စာရေတွက်မယ်
    app.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            count_messages,
            block=False,
        ),
        group=0,
    )

    # Character နာမည်မှန်ရင် Catch လုပ်မယ်
    app.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            handle_guess,
        ),
        group=1,
    )

    app.add_error_handler(error_handler)

    print("🎮 JustFriend Catch Bot စတင်နေပါပြီ!")

    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
